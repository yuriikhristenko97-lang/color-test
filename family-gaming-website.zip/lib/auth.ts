import { cookies } from "next/headers"

export interface VKUser {
  id: number
  first_name: string
  last_name: string
  photo_100?: string
  photo_200?: string
}

export interface AuthSession {
  user: VKUser
  accessToken: string
  expiresAt: number
}

const SESSION_COOKIE = "vk_session"

export async function getSession(): Promise<AuthSession | null> {
  const cookieStore = await cookies()
  const sessionData = cookieStore.get(SESSION_COOKIE)?.value
  
  if (!sessionData) return null
  
  try {
    const session = JSON.parse(sessionData) as AuthSession
    
    // Check if session is expired
    if (session.expiresAt < Date.now()) {
      return null
    }
    
    return session
  } catch {
    return null
  }
}

export async function setSession(session: AuthSession): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE, JSON.stringify(session), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: "/",
  })
}

export async function clearSession(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete(SESSION_COOKIE)
}

export function getVKAuthUrl(redirectUri: string, state: string): string {
  const clientId = process.env.VK_CLIENT_ID
  
  if (!clientId) {
    throw new Error("VK_CLIENT_ID is not configured")
  }

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    display: "page",
    scope: "photos",
    response_type: "code",
    state: state,
    v: "5.131",
  })

  return `https://oauth.vk.com/authorize?${params.toString()}`
}

export async function exchangeCodeForToken(code: string, redirectUri: string): Promise<{
  access_token: string
  expires_in: number
  user_id: number
}> {
  const clientId = process.env.VK_CLIENT_ID
  const clientSecret = process.env.VK_CLIENT_SECRET

  if (!clientId || !clientSecret) {
    throw new Error("VK credentials are not configured")
  }

  const params = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: redirectUri,
    code: code,
  })

  const response = await fetch(`https://oauth.vk.com/access_token?${params.toString()}`)
  
  if (!response.ok) {
    throw new Error("Failed to exchange code for token")
  }

  return response.json()
}

export async function getVKUserInfo(accessToken: string, userId: number): Promise<VKUser> {
  const params = new URLSearchParams({
    user_ids: userId.toString(),
    fields: "photo_100,photo_200",
    access_token: accessToken,
    v: "5.131",
  })

  const response = await fetch(`https://api.vk.com/method/users.get?${params.toString()}`)
  
  if (!response.ok) {
    throw new Error("Failed to get user info")
  }

  const data = await response.json()
  
  if (data.error) {
    throw new Error(data.error.error_msg)
  }

  return data.response[0]
}
