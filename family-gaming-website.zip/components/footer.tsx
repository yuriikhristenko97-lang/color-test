import Link from "next/link"
import { LilacFlower } from "./lilac-flower"

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <LilacFlower size={28} opacity={0.8} />
            <span className="text-sm text-muted-foreground">
              ИП «Донская» — MTA Province #1
            </span>
          </div>
          
          <nav className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
            <Link href="/chatp" className="hover:text-primary transition-colors">
              ЧАТП «Сирень»
            </Link>
            <Link href="/ctk" className="hover:text-primary transition-colors">
              ЧТК
            </Link>
            <Link href="/garage" className="hover:text-primary transition-colors">
              Гараж
            </Link>
          </nav>
          
          <p className="text-sm text-muted-foreground">
            2026 Все права защищены
          </p>
        </div>
      </div>
    </footer>
  )
}
