"use client"

import { useEffect, useState, useRef } from "react"

interface AnimatedCounterProps {
  value: string
  duration?: number
}

export function AnimatedCounter({ value, duration = 2000 }: AnimatedCounterProps) {
  const [displayValue, setDisplayValue] = useState("0")
  const [hasAnimated, setHasAnimated] = useState(false)
  const ref = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated) {
          setHasAnimated(true)
          animateValue()
        }
      },
      { threshold: 0.5 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [hasAnimated])

  const animateValue = () => {
    // Extract numeric part and suffix
    const numericMatch = value.match(/^(\d+)/)
    const suffix = value.replace(/^\d+/, "")
    
    if (!numericMatch) {
      setDisplayValue(value)
      return
    }

    const targetNumber = parseInt(numericMatch[1], 10)
    const startTime = performance.now()

    const updateValue = (currentTime: number) => {
      const elapsed = currentTime - startTime
      const progress = Math.min(elapsed / duration, 1)
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4)
      const currentValue = Math.floor(easeOutQuart * targetNumber)
      
      setDisplayValue(currentValue + suffix)

      if (progress < 1) {
        requestAnimationFrame(updateValue)
      } else {
        setDisplayValue(value)
      }
    }

    requestAnimationFrame(updateValue)
  }

  return <span ref={ref}>{displayValue}</span>
}
