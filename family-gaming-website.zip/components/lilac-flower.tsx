"use client"

import { cn } from "@/lib/utils"

interface LilacFlowerProps {
  className?: string
  size?: number
  opacity?: number
}

export function LilacFlower({ className, size = 40, opacity = 0.6 }: LilacFlowerProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={cn("text-primary", className)}
      style={{ opacity }}
    >
      {/* Цветок сирени - 4 лепестка */}
      <g fill="currentColor">
        <ellipse cx="50" cy="30" rx="12" ry="18" />
        <ellipse cx="50" cy="70" rx="12" ry="18" />
        <ellipse cx="30" cy="50" rx="18" ry="12" />
        <ellipse cx="70" cy="50" rx="18" ry="12" />
        <circle cx="50" cy="50" r="8" className="text-accent" fill="currentColor" />
      </g>
    </svg>
  )
}

export function LilacBranch({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 300"
      className={cn("w-full h-full", className)}
      fill="none"
    >
      {/* Веточка */}
      <path
        d="M100 280 Q90 200, 100 150 Q110 100, 95 50"
        stroke="currentColor"
        strokeWidth="3"
        className="text-lilac-700"
        fill="none"
      />
      
      {/* Цветки сирени на ветке */}
      <g className="text-primary">
        <circle cx="85" cy="60" r="6" fill="currentColor" opacity="0.9" />
        <circle cx="95" cy="45" r="5" fill="currentColor" opacity="0.8" />
        <circle cx="105" cy="55" r="6" fill="currentColor" opacity="0.85" />
        <circle cx="90" cy="75" r="5" fill="currentColor" opacity="0.75" />
        <circle cx="100" cy="70" r="6" fill="currentColor" opacity="0.9" />
        <circle cx="110" cy="65" r="5" fill="currentColor" opacity="0.7" />
        
        <circle cx="88" cy="95" r="6" fill="currentColor" opacity="0.85" />
        <circle cx="98" cy="85" r="5" fill="currentColor" opacity="0.8" />
        <circle cx="108" cy="90" r="6" fill="currentColor" opacity="0.9" />
        <circle cx="95" cy="105" r="5" fill="currentColor" opacity="0.75" />
        <circle cx="105" cy="100" r="6" fill="currentColor" opacity="0.85" />
        
        <circle cx="92" cy="125" r="5" fill="currentColor" opacity="0.8" />
        <circle cx="102" cy="120" r="6" fill="currentColor" opacity="0.9" />
        <circle cx="98" cy="135" r="5" fill="currentColor" opacity="0.7" />
        <circle cx="108" cy="130" r="5" fill="currentColor" opacity="0.85" />
      </g>
      
      {/* Листья */}
      <g className="text-green-600" fill="currentColor" opacity="0.7">
        <ellipse cx="75" cy="180" rx="20" ry="10" transform="rotate(-30 75 180)" />
        <ellipse cx="125" cy="200" rx="20" ry="10" transform="rotate(30 125 200)" />
        <ellipse cx="80" cy="240" rx="18" ry="8" transform="rotate(-20 80 240)" />
      </g>
    </svg>
  )
}

export function FloatingPetals({ count = 8 }: { count?: number }) {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="absolute animate-float"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${i * 0.5}s`,
            animationDuration: `${15 + Math.random() * 10}s`,
          }}
        >
          <LilacFlower size={20 + Math.random() * 20} opacity={0.15 + Math.random() * 0.15} />
        </div>
      ))}
    </div>
  )
}
