"use client"

import { ReactNode } from "react"
import { Header } from "./header"
import { Footer } from "./footer"
import { FloatingPetals } from "./lilac-flower"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Lock, Users, FileText, Bell, LucideIcon } from "lucide-react"
import Link from "next/link"

interface Employee {
  name: string
  position: string
  rank?: string
}

interface Rule {
  title: string
  content: string
}

interface News {
  title: string
  date: string
  content: string
}

interface DivisionLayoutProps {
  title: string
  description: string
  icon: LucideIcon
  employees: Employee[]
  rules: Rule[]
  news: News[]
  adminHref: string
  children?: ReactNode
}

export function DivisionLayout({
  title,
  description,
  icon: Icon,
  employees,
  rules,
  news,
  adminHref,
}: DivisionLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col relative">
      <FloatingPetals count={8} />
      <Header />

      <main className="flex-1 relative z-10">
        {/* Hero */}
        <section className="py-12 lg:py-20 bg-gradient-to-b from-primary/5 to-transparent">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                    {title}
                  </h1>
                  <p className="text-muted-foreground mt-1">
                    {description}
                  </p>
                </div>
              </div>
              <Button asChild variant="outline" className="gap-2">
                <Link href={adminHref}>
                  <Lock className="w-4 h-4" />
                  Админ-панель
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Content Tabs */}
        <section className="py-8 lg:py-12">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="employees" className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-3 mb-8">
                <TabsTrigger value="employees" className="gap-2">
                  <Users className="w-4 h-4 hidden sm:inline" />
                  Сотрудники
                </TabsTrigger>
                <TabsTrigger value="rules" className="gap-2">
                  <FileText className="w-4 h-4 hidden sm:inline" />
                  Устав
                </TabsTrigger>
                <TabsTrigger value="news" className="gap-2">
                  <Bell className="w-4 h-4 hidden sm:inline" />
                  Новости
                </TabsTrigger>
              </TabsList>

              <TabsContent value="employees">
                <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Список сотрудников</CardTitle>
                    <CardDescription>
                      Текущий состав подразделения
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3">
                      {employees.map((employee, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold">
                              {employee.name.charAt(0)}
                            </div>
                            <div>
                              <p className="font-medium text-foreground">
                                {employee.name}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {employee.position}
                              </p>
                            </div>
                          </div>
                          {employee.rank && (
                            <Badge variant="secondary">{employee.rank}</Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="rules">
                <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Устав и правила</CardTitle>
                    <CardDescription>
                      Обязательно к ознакомлению для всех сотрудников
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {rules.map((rule, i) => (
                        <div key={i} className="border-b border-border/50 pb-4 last:border-0 last:pb-0">
                          <h4 className="font-semibold text-foreground mb-2">
                            {i + 1}. {rule.title}
                          </h4>
                          <p className="text-muted-foreground text-sm leading-relaxed">
                            {rule.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="news">
                <div className="space-y-4">
                  {news.map((item, i) => (
                    <Card key={i} className="border-border/50 bg-card/80 backdrop-blur-sm">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <Badge variant="outline" className="text-xs">
                            {item.date}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          {item.content}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
