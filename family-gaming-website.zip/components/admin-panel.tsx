import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Users, 
  FileText, 
  Bell, 
  Settings, 
  Plus, 
  Pencil, 
  Trash2, 
  LogOut,
  Shield
} from "lucide-react"
import { AuthSession } from "@/lib/auth"
import Image from "next/image"

interface AdminPanelProps {
  session: AuthSession
  divisionName: string
}

export function AdminPanel({ session, divisionName }: AdminPanelProps) {
  const { user } = session

  return (
    <div className="space-y-6">
      {/* Admin Header */}
      <Card className="border-primary/30 bg-gradient-to-r from-primary/5 to-accent/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {user.photo_100 ? (
                <Image
                  src={user.photo_100}
                  alt={`${user.first_name} ${user.last_name}`}
                  width={48}
                  height={48}
                  className="rounded-full border-2 border-primary/30"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold text-lg">
                  {user.first_name.charAt(0)}
                </div>
              )}
              <div>
                <CardTitle className="flex items-center gap-2">
                  {user.first_name} {user.last_name}
                  <Badge className="bg-primary/20 text-primary hover:bg-primary/30">
                    <Shield className="w-3 h-3 mr-1" />
                    Администратор
                  </Badge>
                </CardTitle>
                <CardDescription>
                  Панель управления {divisionName}
                </CardDescription>
              </div>
            </div>
            <form action="/api/auth/logout" method="POST">
              <Button type="submit" variant="outline" size="sm" className="gap-2">
                <LogOut className="w-4 h-4" />
                Выйти
              </Button>
            </form>
          </div>
        </CardHeader>
      </Card>

      {/* Admin Tabs */}
      <Tabs defaultValue="employees" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="employees" className="gap-2">
            <Users className="w-4 h-4" />
            <span className="hidden sm:inline">Сотрудники</span>
          </TabsTrigger>
          <TabsTrigger value="rules" className="gap-2">
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">Устав</span>
          </TabsTrigger>
          <TabsTrigger value="news" className="gap-2">
            <Bell className="w-4 h-4" />
            <span className="hidden sm:inline">Новости</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-2">
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Настройки</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="employees">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Управление сотрудниками</CardTitle>
                <CardDescription>Добавление, редактирование и удаление сотрудников</CardDescription>
              </div>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Добавить
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: "Александр Донской", position: "Директор" },
                  { name: "Михаил Сиренев", position: "Заместитель" },
                  { name: "Дмитрий Волков", position: "Диспетчер" },
                ].map((emp, i) => (
                  <div key={i} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold">
                        {emp.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium">{emp.name}</p>
                        <p className="text-sm text-muted-foreground">{emp.position}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon">
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Редактирование устава</CardTitle>
                <CardDescription>Изменение правил и регламента</CardDescription>
              </div>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Добавить пункт
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { title: "Дресс-код", content: "Все сотрудники обязаны носить форменную одежду..." },
                  { title: "Субординация", content: "Соблюдение иерархии обязательно..." },
                ].map((rule, i) => (
                  <div key={i} className="p-4 rounded-lg border border-border/50">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold">{i + 1}. {rule.title}</h4>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon">
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{rule.content}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="news">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Управление новостями</CardTitle>
                <CardDescription>Публикация объявлений и новостей</CardDescription>
              </div>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Создать новость
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { title: "Набор новых водителей", date: "15.12.2024" },
                  { title: "Обновление автопарка", date: "10.12.2024" },
                ].map((news, i) => (
                  <div key={i} className="flex items-center justify-between p-4 rounded-lg border border-border/50">
                    <div>
                      <h4 className="font-medium">{news.title}</h4>
                      <p className="text-sm text-muted-foreground">{news.date}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon">
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Настройки подразделения</CardTitle>
              <CardDescription>Общие настройки и конфигурация</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-secondary/50">
                <h4 className="font-medium mb-2">Название подразделения</h4>
                <p className="text-muted-foreground">{divisionName}</p>
              </div>
              <div className="p-4 rounded-lg bg-secondary/50">
                <h4 className="font-medium mb-2">Описание</h4>
                <p className="text-muted-foreground">Нажмите для редактирования...</p>
              </div>
              <Button variant="outline" className="w-full">
                Сохранить изменения
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
