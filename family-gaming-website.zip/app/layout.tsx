import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin", "cyrillic"],
  variable: '--font-inter'
});

export const metadata: Metadata = {
  title: 'ИП «Донская» | MTA Province #1',
  description: 'Официальный сайт игровой организации ИП «Донская» на MTA Province #1. ЧАТП «Сирень», ЧТК, Гараж.',
  keywords: ['MTA Province', 'ИП Донская', 'ЧАТП Сирень', 'ЧТК', 'игровая организация'],
}

export const viewport: Viewport = {
  themeColor: '#9b6dcc',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" className="bg-background">
      <body className={`${inter.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
