import { redirect } from "next/navigation"
import { getVKAuthUrl } from "@/lib/auth"
import { headers } from "next/headers"

interface LoginPageProps {
  searchParams: Promise<{ redirect?: string }>
}

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const params = await searchParams
  const redirectPath = params.redirect || "/"
  
  const headersList = await headers()
  const host = headersList.get("host") || "localhost:3000"
  const protocol = process.env.NODE_ENV === "production" ? "https" : "http"
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || `${protocol}://${host}`
  
  const redirectUri = `${baseUrl}/api/auth/vk/callback`
  const state = encodeURIComponent(redirectPath)
  
  try {
    const authUrl = getVKAuthUrl(redirectUri, state)
    redirect(authUrl)
  } catch {
    redirect(`/auth/error?message=${encodeURIComponent("VK авторизация не настроена")}`)
  }
}
