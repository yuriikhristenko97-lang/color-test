import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingPetals, LilacBranch } from "@/components/lilac-flower"
import { AnimatedCounter } from "@/components/animated-counter"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Truck, Car, Warehouse, ArrowRight, Users, Shield, Clock, MapPin, Trophy, Zap, ExternalLink } from "lucide-react"

const divisions = [
  {
    title: "ЧАТП «Сирень»",
    description: "Частное автотранспортное предприятие. Пассажирские и грузовые перевозки по городу и области.",
    icon: Truck,
    href: "/chatp",
    vkHref: "https://vk.ru/chtp_siren",
    color: "from-primary/20 to-accent/20",
  },
  {
    title: "ЧТК",
    description: "Частная транспортная компания от ИП «Донская». Профессиональные транспортные услуги.",
    icon: Car,
    href: "/ctk",
    vkHref: "https://vk.ru/chtk_ip_donskaya",
    color: "from-accent/20 to-lilac-300/20",
  },
  {
    title: "Гараж",
    description: "Автопарк организации. Техническое обслуживание и хранение транспорта.",
    icon: Warehouse,
    href: "/garage",
    color: "from-lilac-300/20 to-primary/20",
  },
]

const features = [
  {
    icon: Users,
    title: "Сплоченная команда",
    description: "Более 40 активных сотрудников",
  },
  {
    icon: Shield,
    title: "Надежность",
    description: "Работаем стабильно и качественно",
  },
  {
    icon: Clock,
    title: "24/7 на связи",
    description: "Всегда готовы помочь",
  },
]

const stats = [
  { value: "40+", label: "Сотрудников", icon: Users },
  { value: "3", label: "Подразделения", icon: MapPin },
  { value: "65", label: "Единиц техники", icon: Car },
  { value: "2026", label: "Год основания", icon: Trophy },
]



export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col relative">
      <FloatingPetals count={12} />
      <Header />
      
      <main className="flex-1 relative z-10">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 lg:py-32">
          <div className="absolute left-0 top-0 w-48 h-80 opacity-20 hidden lg:block">
            <LilacBranch />
          </div>
          <div className="absolute right-0 bottom-0 w-48 h-80 opacity-20 hidden lg:block transform rotate-180">
            <LilacBranch />
          </div>
          
          <div className="container mx-auto px-4 text-center relative z-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              MTA Province #1
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance">
              ИП <span className="text-primary">«Донская»</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 text-pretty">
              Крупнейшая транспортная организация в игре. 
              Объединяем ЧАТП «Сирень», ЧТК и собственный автопарк.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button asChild size="lg" className="min-w-[180px]">
                <Link href="/chatp">
                  Узнать больше
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="min-w-[180px]">
                <Link href="/garage">
                  Наш автопарк
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 border-y border-border/30 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 group-hover:bg-primary/20 transition-all">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-3xl md:text-4xl font-bold text-primary mb-1">
                    <AnimatedCounter value={stat.value} />
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Divisions Section */}
        <section className="py-16 lg:py-24 bg-card/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Наши подразделения
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Три ключевых направления работы нашей организации
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              {divisions.map((division) => (
                <Card key={division.href} className="h-full transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1 border-border/50 bg-card/80 backdrop-blur-sm">
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${division.color} flex items-center justify-center mb-4`}>
                      <division.icon className="w-7 h-7 text-primary" />
                    </div>
                    <CardTitle className="text-xl">
                      {division.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base mb-4">
                      {division.description}
                    </CardDescription>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <Button asChild variant="default" size="sm" className="flex-1">
                        <Link href={division.href}>
                          Подробнее
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </Link>
                      </Button>
                      {division.vkHref && (
                        <Button asChild variant="outline" size="sm" className="flex-1">
                          <a href={division.vkHref} target="_blank" rel="noopener noreferrer">
                            Группа ВК
                            <ExternalLink className="w-3 h-3 ml-1" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature) => (
                <div key={feature.title} className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>



        {/* CTA Section */}
        <section className="py-16 lg:py-20">
          <div className="container mx-auto px-4">
            <Card className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 border-primary/20 overflow-hidden relative">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5YjZkY2MiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
              <CardContent className="p-8 md:p-12 text-center relative">
                <Zap className="w-10 h-10 text-primary mx-auto mb-4" />
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4 text-balance">
                  Хочешь стать частью нашей команды?
                </h2>
                <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
                  Мы всегда рады новым сотрудникам. Присоединяйся к ИП «Донская» на MTA Province #1!
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button asChild size="lg" className="min-w-[160px]">
                    <a href="https://vk.ru/donskie_family" target="_blank" rel="noopener noreferrer">
                      <Users className="w-4 h-4 mr-2" />
                      Наша группа ВК
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
