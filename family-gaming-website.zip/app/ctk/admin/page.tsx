import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingPetals } from "@/components/lilac-flower"
import { AdminPanel } from "@/components/admin-panel"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Car, Lock } from "lucide-react"
import Link from "next/link"
import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Админ-панель ЧТК | ИП «Донская»",
  description: "Панель управления ЧТК",
}

export default async function CTKAdminPage() {
  const session = await getSession()

  return (
    <div className="min-h-screen flex flex-col relative">
      <FloatingPetals count={6} />
      <Header />

      <main className="flex-1 relative z-10">
        <section className="py-8 lg:py-12 bg-gradient-to-b from-primary/5 to-transparent">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Car className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                  ЧТК
                </h1>
                <p className="text-muted-foreground">
                  Админ-панель
                </p>
              </div>
            </div>

            {session ? (
              <AdminPanel session={session} divisionName="ЧТК" />
            ) : (
              <Card className="max-w-md mx-auto border-border/50 bg-card/80 backdrop-blur-sm">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Lock className="w-8 h-8 text-primary" />
                  </div>
                  <CardTitle>Требуется авторизация</CardTitle>
                  <CardDescription>
                    Для доступа к админ-панели необходимо войти через ВКонтакте
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-3">
                  <Button asChild className="w-full gap-2 bg-[#0077FF] hover:bg-[#0066DD]">
                    <Link href="/auth/login?redirect=/ctk/admin">
                      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12.785 16.241s.288-.032.436-.194c.136-.148.132-.427.132-.427s-.02-1.304.587-1.496c.596-.19 1.365 1.26 2.18 1.817.616.422 1.084.33 1.084.33l2.178-.03s1.14-.07.6-.964c-.045-.073-.32-.659-1.645-1.862-1.387-1.26-1.2-1.056.47-3.234.94-1.225 1.316-1.973 1.198-2.293-.112-.305-.804-.225-.804-.225l-2.45.015s-.182-.025-.317.056c-.132.079-.216.262-.216.262s-.388 1.031-.905 1.909c-1.09 1.852-1.526 1.95-1.704 1.836-.415-.267-.311-1.07-.311-1.642 0-1.784.27-2.528-.527-2.722-.265-.064-.46-.107-1.138-.114-.87-.01-1.605.003-2.022.208-.278.136-.492.44-.361.457.161.022.527.1.721.364.25.34.242 1.108.242 1.108s.144 2.098-.336 2.358c-.33.18-.782-.187-1.754-1.866-.498-.86-.874-1.81-.874-1.81s-.072-.178-.202-.273c-.156-.115-.375-.152-.375-.152l-2.327.015s-.35.01-.478.161c-.114.135-.009.414-.009.414s1.824 4.266 3.89 6.415c1.893 1.97 4.043 1.84 4.043 1.84h.974z"/>
                      </svg>
                      Войти через ВКонтакте
                    </Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full">
                    <Link href="/ctk">
                      Вернуться назад
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
