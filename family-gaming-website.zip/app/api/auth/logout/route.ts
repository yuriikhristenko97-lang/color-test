import { NextRequest, NextResponse } from "next/server"
import { clearSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  await clearSession()
  
  const referer = request.headers.get("referer") || "/"
  const redirectUrl = new URL(referer).pathname.replace(/\/admin$/, "")
  
  return NextResponse.redirect(new URL(redirectUrl || "/", request.url))
}

export async function GET(request: NextRequest) {
  await clearSession()
  
  return NextResponse.redirect(new URL("/", request.url))
}
