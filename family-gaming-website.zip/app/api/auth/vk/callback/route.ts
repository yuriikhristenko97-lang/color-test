import { NextRequest, NextResponse } from "next/server"
import { exchangeCodeForToken, getVKUserInfo, setSession } from "@/lib/auth"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const code = searchParams.get("code")
  const state = searchParams.get("state")
  const error = searchParams.get("error")

  // Handle VK OAuth errors
  if (error) {
    const errorDescription = searchParams.get("error_description") || "Authorization failed"
    return NextResponse.redirect(
      new URL(`/auth/error?message=${encodeURIComponent(errorDescription)}`, request.url)
    )
  }

  if (!code || !state) {
    return NextResponse.redirect(
      new URL("/auth/error?message=Missing%20authorization%20code", request.url)
    )
  }

  try {
    // Decode state to get redirect path
    const redirectPath = decodeURIComponent(state)
    
    // Get the base URL for redirect URI
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || request.nextUrl.origin
    const redirectUri = `${baseUrl}/api/auth/vk/callback`

    // Exchange code for access token
    const tokenData = await exchangeCodeForToken(code, redirectUri)
    
    // Get user info from VK
    const user = await getVKUserInfo(tokenData.access_token, tokenData.user_id)
    
    // Create session
    await setSession({
      user,
      accessToken: tokenData.access_token,
      expiresAt: Date.now() + tokenData.expires_in * 1000,
    })

    // Redirect to the original destination
    return NextResponse.redirect(new URL(redirectPath, request.url))
  } catch (err) {
    console.error("VK OAuth error:", err)
    return NextResponse.redirect(
      new URL("/auth/error?message=Authentication%20failed", request.url)
    )
  }
}
